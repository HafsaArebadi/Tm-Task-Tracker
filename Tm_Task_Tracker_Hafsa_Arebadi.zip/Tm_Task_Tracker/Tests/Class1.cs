﻿namespace Tests
{
    public class Class1
    {

    }
}