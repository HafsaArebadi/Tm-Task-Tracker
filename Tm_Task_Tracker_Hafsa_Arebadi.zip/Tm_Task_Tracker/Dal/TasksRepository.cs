﻿using Dal;
using models;
using MongoDB.Driver.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

public class TasksRepository 
{
    private static readonly string connectionString;

    public static void ListTasks()
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();

            SqlCommand command = new SqlCommand("SELECT * FROM Tasks", connection);
            SqlDataReader reader = command.ExecuteReader();

            Console.WriteLine("Takenlijst:");
            while (reader.Read())
            {
                int id = (int)reader["Id"];
                string title = (string)reader["Title"];
                string description = (string)reader["Description"];
                string status = (string)reader["Status"];
                DateTime? startedAt = reader["StartedAt"] as DateTime?;
                DateTime? finishedAt = reader["FinishedAt"] as DateTime?;
                DateTime createdAt = (DateTime)reader["CreatedAt"];
                DateTime lastUpdatedAt = (DateTime)reader["LastUpdatedAt"];

                Console.WriteLine($"ID: {id}, Titel: {title}, Status: {status}");
            }

            reader.Close();
        }
    }

    public static void CreateTask(ConnectionString connectionString)
    {
        Console.WriteLine("Voer de taakgegevens in:");

        Console.Write("Titel: ");
        string title = Console.ReadLine();

        Console.Write("Beschrijving: ");
        string description = Console.ReadLine();

        Console.Write("Status: ");
        string status = Console.ReadLine();

        DateTime createdAt = DateTime.Now;
        DateTime lastUpdatedAt = DateTime.Now;

        using (SqlConnection connection = new SqlConnection())
        {
            connection.Open();

            SqlCommand command = new SqlCommand("INSERT INTO Tasks (Title, Description, Status, CreatedAt, LastUpdatedAt) VALUES (@Title, @Description, @Status, @CreatedAt, @LastUpdatedAt)", connection);
            command.Parameters.AddWithValue("@Title", title);
            command.Parameters.AddWithValue("@Description", description);
            command.Parameters.AddWithValue("@Status", status);
            command.Parameters.AddWithValue("@CreatedAt", createdAt);
            command.Parameters.AddWithValue("@LastUpdatedAt", lastUpdatedAt);

            command.ExecuteNonQuery();
        }

        Console.WriteLine("Taak is aangemaakt.");
    }

    public static void UpdateTask()
    {
        Console.Write("Voer het ID van de taak in die u wilt bijwerken: ");
        int taskId;
        if (int.TryParse(Console.ReadLine(), out taskId))
        {
            Console.WriteLine("Voer de nieuwe taakgegevens in:");

            Console.Write("Titel: ");
            string title = Console.ReadLine();

            Console.Write("Beschrijving: ");
            string description = Console.ReadLine();

            Console.Write("Status: ");
            string status = Console.ReadLine();

            DateTime lastUpdatedAt = DateTime.Now;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand("UPDATE Tasks SET Title = @Title, Description = @Description, Status = @Status, LastUpdatedAt = @LastUpdatedAt WHERE Id = @Id", connection);
                command.Parameters.AddWithValue("@Title", title);
                command.Parameters.AddWithValue("@Description", description);
                command.Parameters.AddWithValue("@Status", status);
                command.Parameters.AddWithValue("@LastUpdatedAt", lastUpdatedAt);
                command.Parameters.AddWithValue("@Id", taskId);

                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Console.WriteLine("Taak is bijgewerkt.");
                }
                else
                {
                    Console.WriteLine("Taak met dit ID bestaat niet.");
                }
            }
        }
        else
        {
            Console.WriteLine("Ongeldige invoer. Voer een geldig nummer in.");
        }
    }

    public static void DeleteTask()
    {
        Console.Write("Voer het ID van de taak in die u wilt verwijderen: ");
        int taskId;
        if (int.TryParse(Console.ReadLine(), out taskId))
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand("DELETE FROM Tasks WHERE Id = @Id", connection);
                command.Parameters.AddWithValue("@Id", taskId);

                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    Console.WriteLine("Taak is verwijderd.");
                }
                else
                {
                    Console.WriteLine("Taak met dit ID bestaat niet.");
                }
            }
        }
        else
        {
            Console.WriteLine("Ongeldige invoer. Voer een geldig nummer in.");
        }
    }


}
