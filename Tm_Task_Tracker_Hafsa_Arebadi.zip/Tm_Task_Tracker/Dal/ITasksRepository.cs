﻿using System;
using System.Collections.Generic;
using System.Text;
using models;



namespace Dal
{
    public interface ITasksRepository
    {

   

    }
}
