﻿using MongoDB.Driver.Core.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;



namespace models
{
   

    public class Task
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime LastUpdatedAt { get; set; }
    }

    class Program
    {
        static List<Task> tasks = new List<Task>();

        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Kies een actie:");
                Console.WriteLine("1. Taken ophalen");
                Console.WriteLine("2. Taak aanmaken");
                Console.WriteLine("3. Taak updaten");
                Console.WriteLine("4. Taak verwijderen");
                Console.WriteLine("5. Afsluiten");

                int choice;
                if (int.TryParse(Console.ReadLine(), out choice))
                {
                    switch (choice)
                    {
                        case 1:
                            ListTasks();
                            break;
                        case 2:
                            CreateTask();
                            break;
                        case 3:
                            UpdateTask();
                            break;
                        case 4:
                            DeleteTask();
                            break;
                        case 5:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Ongeldige keuze. Probeer opnieuw.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Ongeldige invoer. Voer een geldig nummer in.");
                }
            }
        }

        static void ListTasks()
        {
            Console.WriteLine("Takenlijst:");
            foreach (var task in tasks)
            {
                Console.WriteLine($"ID: {task.Id}, Titel: {task.Title}, Descriptie: {task.Description}, Status: {task.Status}");
            }
        }

        static void CreateTask()
        {
            Console.WriteLine("Voer de taakgegevens in:");

            Console.Write("Titel: ");
            string title = Console.ReadLine();

            Console.Write("Beschrijving: ");
            string description = Console.ReadLine();

            Console.Write("Status: ");
            string status = Console.ReadLine();

            int newId = tasks.Count + 1;
            DateTime createdAt = DateTime.Now;
            DateTime lastUpdatedAt = DateTime.Now;

            Task newTask = new Task
            {
                Id = newId,
                Title = title,
                Description = description,
                Status = status,
                CreatedAt = createdAt,
                LastUpdatedAt = lastUpdatedAt
            };

            tasks.Add(newTask); 

            Console.WriteLine("Taak is aangemaakt.");
        }

        static void UpdateTask()
        {
            Console.Write("Voer het ID van de taak in die u wilt bijwerken: ");
            int taskId;
            if (int.TryParse(Console.ReadLine(), out taskId))
            {
                Task existingTask = tasks.Find(task => task.Id == taskId);
                if (existingTask != null)
                {
                    Console.WriteLine("Voer de nieuwe taakgegevens in:");

                    Console.Write("Titel: ");
                    existingTask.Title = Console.ReadLine();

                    Console.Write("Beschrijving: ");
                    existingTask.Description = Console.ReadLine();

                    Console.Write("Status: ");
                    existingTask.Status = Console.ReadLine();

                    existingTask.LastUpdatedAt = DateTime.Now;

                    Console.WriteLine("Taak is bijgewerkt.");
                }
                else
                {
                    Console.WriteLine("Taak met dit ID bestaat niet.");
                }
            }
            else
            {
                Console.WriteLine("Ongeldige invoer. Voer een geldig nummer in.");
            }
        }

        static void DeleteTask()
        {
            Console.Write("Voer het ID van de taak in die u wilt verwijderen: ");
            int taskId;
            if (int.TryParse(Console.ReadLine(), out taskId))
            {
                Task taskToRemove = tasks.Find(task => task.Id == taskId);
                if (taskToRemove != null)
                {
                    tasks.Remove(taskToRemove);
                    Console.WriteLine("Taak is verwijderd.");
                }
                else
                {
                    Console.WriteLine("Taak met dit ID bestaat niet.");
                }
            }
            else
            {
                Console.WriteLine("Ongeldige invoer. Voer een geldig nummer in.");
            }
        }
    }
}