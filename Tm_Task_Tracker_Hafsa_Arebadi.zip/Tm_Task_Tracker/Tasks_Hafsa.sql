﻿DROP TABLE IF EXISTS Tasks.Taak;
DROP TABLE IF EXISTS Tasks.Comments;
GO

DROP SCHEMA IF EXISTS Tasks;
GO

CREATE SCHEMA Tasks;
GO

USE Tasks

-- Maak de Tasks-tabel aan
CREATE TABLE Tasks.Taak
(
    Id INT PRIMARY KEY IDENTITY(1,1),
    Title NVARCHAR(255) NOT NULL,
    Description NVARCHAR(MAX),
    Status NVARCHAR(50) NOT NULL,
    StartedAt DATETIME,
    FinishedAt DATETIME,
    CreatedAt DATETIME NOT NULL,
    LastUpdatedAt DATETIME NOT NULL
)

-- Maak de Comments-tabel aan
CREATE TABLE Tasks.Comments
(
    Id INT PRIMARY KEY IDENTITY(1,1),
    CreatedAt DATETIME NOT NULL,
    Reason INT NOT NULL
)


-- Insert statements for Tasks.Taak table
INSERT INTO Tasks.Taak(Title, Description, Status, StartedAt, FinishedAt, CreatedAt, LastUpdatedAt) VALUES ('Poetsen', 'Wat moet er gepoetst worden', '', '', '', '', '');
INSERT INTO Tasks.Taak(Title, Description, Status, StartedAt, FinishedAt, CreatedAt, LastUpdatedAt) VALUES ('Tuinieren', 'Wat moet er getuinierd worden', '', '', '', '', '');
INSERT INTO Tasks.Taak(Title, Description, Status, StartedAt, FinishedAt, CreatedAt, LastUpdatedAt) VALUES ('GarageVerkoop', 'Wat wordt er verkocht?', '', '', '', '', '');
INSERT INTO Tasks.Taak(Title, Description, Status, StartedAt, FinishedAt, CreatedAt, LastUpdatedAt) VALUES ('Winkelen', 'Wat moet er gekocht worden', '', '', '', '', '');

-- Insert statements for Tasks.Comments table
INSERT INTO Tasks.Comments(CreatedAt, Reason) VALUES ('', '');
INSERT INTO Tasks.Comments(CreatedAt, Reason) VALUES ('', '');
INSERT INTO Tasks.Comments(CreatedAt, Reason) VALUES ('', '');
INSERT INTO Tasks.Comments(CreatedAt, Reason) VALUES ('', '');