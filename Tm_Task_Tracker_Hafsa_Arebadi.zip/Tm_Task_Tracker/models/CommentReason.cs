﻿using System;
using System.Collections.Generic;


namespace models
{
    public enum CommentReason
    {
        Postponed,
        Active
    }
}
